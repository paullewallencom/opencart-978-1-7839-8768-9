<?php
// Text
$_['text_empty'] = 'There are no feedbacks yet!';
$_['heading_title'] = 'Feedbacks';

