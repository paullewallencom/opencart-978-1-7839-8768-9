<?php
// Text
$_['text_title']  = 'Total Cost Based Shipping';
$_['text_weight'] = 'Total Cost:';